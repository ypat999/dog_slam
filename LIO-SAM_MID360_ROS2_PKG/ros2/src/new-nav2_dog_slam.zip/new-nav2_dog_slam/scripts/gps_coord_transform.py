#!/usr/bin/env python3
"""
高精度动力学校准型GPS坐标转换节点 (室内外穿梭与航点导航解决方案)

功能：
1. 严谨的 WGS84 -> ENU (东北天) 投影计算，消除距离比例尺畸变。
2. 动态 Datum (零点) 建立：出门首次收到高质量 GPS 时，自动锚定基准原点和当前的里程计(雷达)位置。
3. 动力学航向对齐 (Kinematic Alignment)：要求收到 GPS 后，机器狗直行一定距离(如 3米)；系统通过比较 Odom的轨迹向量 和 ENU的轨迹向量，计算出它们之间的夹角 (Yaw Offset)。
4. 完美的无缝融合：一旦航向对齐完成，所有的 GPS 数据都会被精确映射到本开机周期的雷达局部建图坐标系中！
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
from sensor_msgs.msg import NavSatFix
from nav_msgs.msg import Odometry
from std_msgs.msg import Bool, Float64MultiArray
import math

# WGS84 椭球体常数
A_EARTH = 6378137.0
B_EARTH = 6356752.314245
E_SQ = 1.0 - (B_EARTH**2 / A_EARTH**2)

def geodetic_to_ecef(lat, lon, alt):
    """经纬度高程 -> 地心空间直角坐标系 (ECEF)"""
    lat_rad = math.radians(lat)
    lon_rad = math.radians(lon)
    sin_lat = math.sin(lat_rad)
    cos_lat = math.cos(lat_rad)
    sin_lon = math.sin(lon_rad)
    cos_lon = math.cos(lon_rad)
    
    N = A_EARTH / math.sqrt(1.0 - E_SQ * sin_lat**2)
    
    x = (N + alt) * cos_lat * cos_lon
    y = (N + alt) * cos_lat * sin_lon
    z = (N * (1.0 - E_SQ) + alt) * sin_lat
    return x, y, z

def ecef_to_enu(x, y, z, ref_lat, ref_lon, ref_alt):
    """ECEF -> 东北天局部切面坐标系 (ENU)"""
    ref_x, ref_y, ref_z = geodetic_to_ecef(ref_lat, ref_lon, ref_alt)
    
    dx = x - ref_x
    dy = y - ref_y
    dz = z - ref_z
    
    lat_rad = math.radians(ref_lat)
    lon_rad = math.radians(ref_lon)
    sin_lat = math.sin(lat_rad)
    cos_lat = math.cos(lat_rad)
    sin_lon = math.sin(lon_rad)
    cos_lon = math.cos(lon_rad)
    
    e = -sin_lon * dx + cos_lon * dy
    n = -sin_lat * cos_lon * dx - sin_lat * sin_lon * dy + cos_lat * dz
    u = cos_lat * cos_lon * dx + cos_lat * sin_lon * dy + sin_lat * dz
    return e, n, u

def geodetic_to_enu(lat, lon, alt, ref_lat, ref_lon, ref_alt):
    """直接将经纬度转换为基准点所在的局部ENU平面坐标"""
    x, y, z = geodetic_to_ecef(lat, lon, alt)
    return ecef_to_enu(x, y, z, ref_lat, ref_lon, ref_alt)

class GPSCoordTransform(Node):
    def __init__(self):
        super().__init__('gps_coord_transform')
        
        self.declare_parameter('min_valid_gps_count', 5)
        self.declare_parameter('max_position_variance', 20.0)
        self.declare_parameter('alignment_distance', 3.0)  # 需要直行几米来对齐航向
        self.declare_parameter('odom_topic', '/Odometry')
        
        self.min_valid_gps_count = self.get_parameter('min_valid_gps_count').value
        self.max_position_variance = self.get_parameter('max_position_variance').value
        self.alignment_distance = self.get_parameter('alignment_distance').value
        self.odom_topic = self.get_parameter('odom_topic').value
        
        self.gps_sub = self.create_subscription(NavSatFix, '/gps/fix', self.gps_callback, 10)
        self.odom_sub = self.create_subscription(
            Odometry, self.odom_topic, self.odom_callback,
            QoSProfile(depth=10, reliability=ReliabilityPolicy.BEST_EFFORT, durability=DurabilityPolicy.VOLATILE)
        )
        
        self.gps_transformed_pub = self.create_publisher(Odometry, '/gps/odom_transformed', 10)
        self.gps_available_pub = self.create_publisher(Bool, '/gps/available', 10)
        
        # 将变换矩阵的数据暴露出去，方便后续其他节点发送GPS航线规划使用
        self.calibration_status_pub = self.create_publisher(Float64MultiArray, '/gps/calibration_status', 10)
        
        self.current_odom = None
        self.current_gps = None
        
        # 状态机: 0 = 无GPS, 1 = 航向对齐中(请直行), 2 = 对齐完成(正常融合)
        self.state = 0   
        self.valid_gps_count = 0
        self.gps_available = False
        
        # 锚定基准信息 (Datum)
        self.ref_lat = 0.0
        self.ref_lon = 0.0
        self.ref_alt = 0.0
        
        # 锚定雷达起点信息
        self.odom0_x = 0.0
        self.odom0_y = 0.0
        
        # 推算对齐信息
        self.yaw_offset = 0.0
        
        self.get_logger().info('='*50)
        self.get_logger().info('高精度动力学校准型GPS坐标转换节点已启动')
        self.get_logger().info(f'【注意】收到首个GPS后，请控制狗直行大约 {self.alignment_distance} 米以对齐磁北航向！')
        self.get_logger().info('='*50)

    def calculate_position_variance(self, gps_msg):
        if gps_msg.position_covariance_type > 0 and len(gps_msg.position_covariance) >= 6:
            return math.sqrt(gps_msg.position_covariance[0] + gps_msg.position_covariance[4])
        return float('inf')

    def is_gps_valid(self, gps_msg):
        if gps_msg.status.status < 0: return False
        if math.isnan(gps_msg.latitude) or math.isnan(gps_msg.longitude): return False
        if self.calculate_position_variance(gps_msg) > self.max_position_variance: return False
        return True

    def odom_callback(self, odom_msg):
        self.current_odom = odom_msg

    def gps_callback(self, gps_msg):
        self.current_gps = gps_msg
        
        if not self.is_gps_valid(gps_msg):
            self.valid_gps_count = max(0, self.valid_gps_count - 1)
            if self.valid_gps_count == 0 and self.gps_available:
                self.get_logger().warn('✗ GPS信号质量差，暂停处理。')
                self.gps_available = False
        else:
            self.valid_gps_count = min(self.min_valid_gps_count, self.valid_gps_count + 1)
            if self.valid_gps_count == self.min_valid_gps_count and not self.gps_available:
                self.get_logger().info('✓ GPS信号已稳定！')
                self.gps_available = True
        
        available_msg = Bool()
        available_msg.data = self.gps_available
        self.gps_available_pub.publish(available_msg)

        if not self.gps_available or self.current_odom is None:
            self.publish_calibration_status()
            return
            
        if self.state == 0:
            # 建立基点 Datum
            self.ref_lat = gps_msg.latitude
            self.ref_lon = gps_msg.longitude
            self.ref_alt = gps_msg.altitude
            self.odom0_x = self.current_odom.pose.pose.position.x
            self.odom0_y = self.current_odom.pose.pose.position.y
            self.get_logger().info('='*50)
            self.get_logger().info(f'【阶段一: Datum已锚定】 Lat={self.ref_lat:.6f}, Lon={self.ref_lon:.6f}')
            self.get_logger().info(f'提示：请控制机器狗向前方(开阔地带)直行大约 {self.alignment_distance} 米...')
            self.get_logger().info('='*50)
            self.state = 1
            
        elif self.state == 1:
            # 记录运动矢量，对齐航向角
            enu_e, enu_n, enu_u = geodetic_to_enu(
                gps_msg.latitude, gps_msg.longitude, gps_msg.altitude, 
                self.ref_lat, self.ref_lon, self.ref_alt
            )
            
            curr_odom_x = self.current_odom.pose.pose.position.x
            curr_odom_y = self.current_odom.pose.pose.position.y
            
            dist_gps = math.sqrt(enu_e**2 + enu_n**2)
            dist_odom = math.sqrt((curr_odom_x - self.odom0_x)**2 + (curr_odom_y - self.odom0_y)**2)
            
            if dist_gps > self.alignment_distance and dist_odom > self.alignment_distance:
                # 获取 GPS 位移角 和 雷达位移角
                angle_gps = math.atan2(enu_n, enu_e) 
                angle_odom = math.atan2(curr_odom_y - self.odom0_y, curr_odom_x - self.odom0_x)
                
                # 计算需要旋转的偏移量
                self.yaw_offset = angle_odom - angle_gps
                
                self.state = 2
                self.get_logger().info('='*50)
                self.get_logger().info('【阶段二: 航向角已对齐! 系统就绪】')
                self.get_logger().info(f'偏航角修正量(Yaw Offset): {math.degrees(self.yaw_offset):.2f} 度')
                self.get_logger().info('现在GPS与雷达局部地图已建立完美的坐标重叠，EKF可以开始无缝融合。')
                self.get_logger().info('您现在可以依据 /gps/calibration_status 数据，派发任意GPS航线。')
                self.get_logger().info('='*50)
        
        elif self.state == 2:
            # 完全就绪状态：转换并发布
            enu_e, enu_n, enu_u = geodetic_to_enu(
                gps_msg.latitude, gps_msg.longitude, gps_msg.altitude, 
                self.ref_lat, self.ref_lon, self.ref_alt
            )
            
            # 使用 yaw_offset 旋转并平移到 Odom 坐标系
            odom_x_gps = enu_e * math.cos(self.yaw_offset) - enu_n * math.sin(self.yaw_offset) + self.odom0_x
            odom_y_gps = enu_e * math.sin(self.yaw_offset) + enu_n * math.cos(self.yaw_offset) + self.odom0_y
            
            odom = Odometry()
            odom.header = gps_msg.header
            odom.header.frame_id = 'map'
            odom.pose.pose.position.x = odom_x_gps
            odom.pose.pose.position.y = odom_y_gps
            odom.pose.pose.position.z = gps_msg.altitude
            odom.pose.pose.orientation = self.current_odom.pose.pose.orientation
            
            var = max(0.5, self.calculate_position_variance(gps_msg))
            odom.pose.covariance = [var, 0, 0, 0, 0, 0,
                                    0, var, 0, 0, 0, 0,
                                    0, 0, var, 0, 0, 0,
                                    0, 0, 0, 99999, 0, 0,
                                    0, 0, 0, 0, 99999, 0,
                                    0, 0, 0, 0, 0, 99999]
            
            self.gps_transformed_pub.publish(odom)

        self.publish_calibration_status()
        
    def publish_calibration_status(self):
        """发布校准状态矩阵数据，包含 [状态码, Datum_Lat, Datum_Lon, Yaw_Offset, Odom0_x, Odom0_y]"""
        msg = Float64MultiArray()
        # 组装数据，给后续做 “GPS航点 -> 局部XY” 发送提供算法依赖
        data = [
            float(self.state), 
            self.ref_lat, 
            self.ref_lon, 
            self.yaw_offset, 
            self.odom0_x, 
            self.odom0_y
        ]
        msg.data = data
        self.calibration_status_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = GPSCoordTransform()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
