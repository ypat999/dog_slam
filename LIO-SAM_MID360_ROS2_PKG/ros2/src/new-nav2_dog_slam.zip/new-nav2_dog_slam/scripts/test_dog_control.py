#!/usr/bin/env python3
"""
测试机器狗控制转换节点
功能：模拟发送/cmd_vel消息，测试转换节点是否正常工作
"""
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import time

class TestDogControl(Node):
    def __init__(self):
        super().__init__('test_dog_control')
        
        # 创建发布者
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # 测试序列
        self.test_sequence = [
            # 前进
            (0.5, 0.0, 0.0, 2.0),  # (vx, vy, vw, duration)
            # 左转
            (0.0, 0.0, 0.5, 2.0),
            # 后退
            (-0.3, 0.0, 0.0, 2.0),
            # 右转
            (0.0, 0.0, -0.5, 2.0),
            # 停止
            (0.0, 0.0, 0.0, 1.0)
        ]
        
        self.current_test = 0
        self.test_start_time = 0
        
        # 启动测试
        self.create_timer(0.1, self.test_callback)
        self.get_logger().info("TestDogControl node started")
    
    def test_callback(self):
        if self.current_test >= len(self.test_sequence):
            self.get_logger().info("Test completed")
            return
        
        if self.test_start_time == 0:
            self.test_start_time = time.time()
            vx, vy, vw, duration = self.test_sequence[self.current_test]
            self.get_logger().info(f"Starting test {self.current_test + 1}: vx={vx}, vy={vy}, vw={vw}, duration={duration}s")
        
        # 发送速度命令
        msg = Twist()
        msg.linear.x = self.test_sequence[self.current_test][0]
        msg.linear.y = self.test_sequence[self.current_test][1]
        msg.angular.z = self.test_sequence[self.current_test][2]
        self.publisher.publish(msg)
        
        # 检查是否完成当前测试
        current_time = time.time()
        duration = self.test_sequence[self.current_test][3]
        if current_time - self.test_start_time >= duration:
            self.current_test += 1
            self.test_start_time = 0

def main(args=None):
    rclpy.init(args=args)
    node = TestDogControl()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()

if __name__ == '__main__':
    main()